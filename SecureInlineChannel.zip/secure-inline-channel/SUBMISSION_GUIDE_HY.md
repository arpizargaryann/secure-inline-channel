# Քայլ առ քայլ՝ ինչպես հանձնել նախագիծը

## Նախագիծն ինչ է անում

PC1-ը TCP հաղորդագրություն է ուղարկում PC2-ին։ Device1-ը տվյալների հատվածը ծածկագրում է, Device2-ը ստուգում ու վերծանում։ Երկու սարքերը նախապես X25519 Diffie–Hellman handshake են անում և ընդհանուր գաղտնիքից ստանում AES-GCM բանալիները։

## Տարբերակ A — եթե Windows համակարգիչ ունես

1. Տեղադրիր **VirtualBox** կամ VMware Player և Ubuntu 24.04 Desktop ISO (ubuntu.com/download/desktop)։
2. Ստեղծիր Ubuntu վիրտուալ մեքենա՝ մոտ 4 GB RAM, 20 GB disk։
3. Բացիր Ubuntu Terminal (`Ctrl + Alt + T`)։
4. Նախագծի ZIP ֆայլը քաշիր Ubuntu-ի Downloads-ի մեջ և unzip արա։
5. Գործարկիր ստորև ներկայացված հրամանները։

## Տարբերակ B — եթե արդեն Ubuntu ունես

Բացի՛ր Terminal և անցիր 6-րդ քայլին։

## Հրամաններ (յուրաքանչյուրը առանձին հերթով)

```bash
cd ~/Downloads/secure-inline-channel
sudo apt update
sudo apt install -y python3 python3-venv python3-pip iproute2 iputils-ping tcpdump ethtool git
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q
sudo bash scripts/setup_lab.sh
export INLINE_PSK="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
sudo -E bash scripts/start_devices.sh
sudo bash scripts/run_demo.sh
```

**Կարևոր:** ZIP-ի ներսում կարող է գտնվել `secure-inline-channel` պանակը։ Եթե unzip անելուց հետո այլ տեղում է, `cd`-ի հասցեն համապատասխան փոխիր։

## Արդյունքը

Պետք է երևա `ACK: secure channel working`, իսկ log-երում՝ `ENC` և `DEC`։ Սքրինշոթ արա այդ տերմինալի արդյունքից և `pytest`-ի արդյունքից։

## GitHub-ում տեղադրելը (սկսնակի համար)

1. Մտիր https://github.com և գրանցվիր կամ մուտք գործիր։
2. Վերևի աջ մասում սեղմիր **+ → New repository**։
3. Repository name՝ `secure-inline-channel`։ Ընտրիր **Public** (եթե դասախոսին հրապարակային հղում ես տալու)։
4. **Չնշես** “Add a README” (մենք արդեն README ունենք)։ Սեղմիր **Create repository**։
5. Տերմինալում նախագծի պանակից հերթով կատարիր՝

```bash
git init
git add .
git commit -m "Implement secure inline TCP payload channel prototype"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/secure-inline-channel.git
git push -u origin main
```

`YOUR_USERNAME`-ը փոխիր քո GitHub-ի username-ով։ Եթե `git commit`-ը պահանջի անուն և email, նախ կատարիր՝

```bash
git config --global user.name "Your Name"
git config --global user.email "your-email@example.com"
```

Եթե push-ի ժամանակ GitHub-ը password է պահանջում, սովորական GitHub password-ը չի աշխատում. օգտագործիր browser sign-in (`gh auth login`, եթե GitHub CLI ունես), credential manager կամ GitHub personal access token։ Ավելի պարզ տարբերակ՝ GitHub-ի repository էջում սեղմիր **uploading an existing file**, ընտրիր նախագծի ֆայլերը (առանց `.venv` և `runtime` պանակների), սեղմիր **Commit changes**։

6. Բացիր `https://github.com/YOUR_USERNAME/secure-inline-channel` և համոզվիր, որ երևում են README-ն ու բոլոր պանակները։
7. Այդ հղումը ուղարկիր դասախոսին։

## Ինչ պատմել դասախոսին՝ 30 վայրկյանում

«Ես Linux network namespaces-ով սարքել եմ 4 հանգույց՝ PC1, Device1, Device2, PC2։ Device1-ը և Device2-ը նախ կատարում են X25519 Diffie–Hellman handshake՝ PSK authentication-ով, ստանում են AES-GCM բանալիները։ Հետո Device1-ը միայն TCP payload-ն է encrypt անում, ավելացնում 16-byte GCM tag, բայց TCP/IP headers-ը պահում է։ Device2-ը ստուգում է tag-ը, decrypt անում, վերականգնում checksums-ը և փոխանցում PC2-ին։ Nonce-երը յուրաքանչյուր encrypted packet-ի համար եզակի են՝ session-ի մեջ աճող counter-ի միջոցով։ Սա ուսումնական prototype է. առանց լրացուցիչ header-ի counter-ը ստացող կողմը գտնում է սահմանափակ որոնմամբ»։
